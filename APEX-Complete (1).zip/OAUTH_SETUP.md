# Google OAuth Setup for APEX (Gmail + Calendar)

APEX uses **Google OAuth 2.0** to read your Gmail and Calendar **only with your permission**. Your tokens are encrypted and stored only on the backend — never in the APK.

---

## Prerequisites

- Google account
- Phone browser (Chrome)
- Deployed backend URL (e.g., `https://apex-backend.vercel.app`) — see DEPLOYMENT.md

---

## Step 1: Create Google Cloud Project

1. Go to **https://console.cloud.google.com** → sign in
2. Tap ☰ → **IAM & Admin → Create a Project**
   - Project name: `APEX Personal Agent`
   - No organization needed
3. Wait for creation → select the new project (top dropdown)

---

## Step 2: Enable APIs

Go to **APIs & Services → Library** and enable:

- **Gmail API** → Enable
- **Google Calendar API** → Enable
- **Google People API** (for profile) → Enable

---

## Step 3: Configure OAuth Consent Screen

**APIs & Services → OAuth consent screen**

- User Type: **External**
- App name: `APEX`
- User support email: your email
- Developer contact: your email
- Click **Save and Continue**

**Scopes** → **Add or Remove Scopes**:
- `.../auth/gmail.readonly`
- `.../auth/gmail.send`
- `.../auth/gmail.compose`
- `.../auth/calendar.readonly`
- `.../auth/calendar.events`
- `.../auth/userinfo.email`
- `.../auth/userinfo.profile`
- Save

**Test users** → Add your Gmail address (required while app is in Testing mode)

---

## Step 4: Create OAuth Client IDs

**APIs & Services → Credentials → + CREATE CREDENTIALS → OAuth client ID**

- Application type: **Web application**
- Name: `APEX Backend`

**Authorized redirect URIs** (add BOTH):
```
https://YOUR_BACKEND.vercel.app/api/oauth/gmail/callback
https://YOUR_BACKEND.vercel.app/api/oauth/calendar/callback
```

Replace `YOUR_BACKEND` with your Vercel URL.

- Authorized JavaScript origins:
```
https://YOUR_BACKEND.vercel.app
```

Tap **Create** → **Copy Client ID and Client Secret**

> Example:
> - Client ID: `1234567890-abc123.apps.googleusercontent.com`
> - Client Secret: `GOCSPX-1a2b3c4d...`

---

## Step 5: Add to Backend

Go to **Vercel → Your Project → Settings → Environment Variables** and add:

```
GOOGLE_CLIENT_ID=1234567890-abc123.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-...
GOOGLE_REDIRECT_URI=https://YOUR_BACKEND.vercel.app/api/oauth/gmail/callback
GOOGLE_CALENDAR_REDIRECT_URI=https://YOUR_BACKEND.vercel.app/api/oauth/calendar/callback
```

**Redeploy** after adding.

---

## Step 6: Test Connection

1. Open APEX app → **Gmail → Connect Gmail** (or **Calendar → Connect**)
2. You’ll be redirected to Google → choose account → **Allow**
3. Back to APEX → status should be **Connected ✓**

Verify via API:

```bash
curl https://YOUR_BACKEND.vercel.app/api/oauth/gmail/status \
  -H "Authorization: Bearer YOUR_JWT"
# → {"connected":true,"email":"you@gmail.com","scopes":[...]}
```

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `redirect_uri_mismatch` | URI not whitelisted | Add exact URI in Credentials (no trailing slash mismatch) |
| `Access blocked: This app’s request is invalid` | Missing scopes | Add scopes in Consent Screen |
| ` Gmail API not enabled` | API off | Enable Gmail API in Library |
| Token expired | Normal | APEX auto-refreshes using refresh_token; if fails, reconnect |
| `unauthorized_client` | Test user missing | Add your email to Test Users |

---

## Security Notes

- Tokens are **AES-256-GCM encrypted** with `ENCRYPTION_KEY` and stored in `OAuthToken` table
- Backend never logs raw tokens
- You can **Revoke** anytime: **myaccount.google.com → Security → Third-party access → Remove APEX**
- APEX requests **offline access** (`access_type=offline` + `prompt=consent`) to get refresh token — required for background email polling

---

## Publishing (Optional, for other users)

If you want others to use your APEX:

1. Consent Screen → **Publish App** → Submit for verification (Google reviews sensitive scopes like `gmail.send`)
2. Until verified, only Test Users can connect (max 100)
3. For personal use, **keep in Testing** and just keep yourself as Test User — it works indefinitely

---

## Need Help?

Check:
- Google OAuth Playground: https://developers.google.com/oauthplayground/
- APEX logs: Vercel → Logs → filter `/api/oauth`
- App: Settings → Backend Health shows OAuth config status

