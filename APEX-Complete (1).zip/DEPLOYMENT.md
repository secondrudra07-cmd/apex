# APEX Deployment Guide — Phone Only

You can deploy the entire backend without a computer. All steps work from your Android phone browser.

---

## 1. Create Supabase PostgreSQL (Free)

1. Go to **supabase.com** → Sign up → **New Project**
   - Name: `apex`
   - Region: closest to you
   - Set a strong DB password → **Save it**

2. Wait ~2 minutes for project to provision.

3. Go to **Project Settings → Database → Connection String**
   - Choose **URI** tab, **Transaction pooler** → copy `DATABASE_URL` (port 6543, `?pgbouncer=true`)
   - Also copy **Session pooler** (port 5432) as `DIRECT_URL`

4. Keep these two URLs — you’ll paste them into Vercel.

---

## 2. Deploy Backend to Vercel (Free)

1. Go to **vercel.com** → Sign up with GitHub → **Add New Project** → Import your forked `apex` repo
   - Framework Preset: **Next.js**
   - Root Directory: `backend`

2. Before deploying, add **Environment Variables** (tap “Add” for each):
   ```
   DATABASE_URL = (your transaction pooler URL)
   DIRECT_URL   = (your session pooler URL)
   JWT_SECRET   = (generate: open https://generate-secret.vercel.app/32 → copy hex)
   ENCRYPTION_KEY = (32-byte hex: openssl rand -hex 32 on any online generator — use https://generate-random.org/hex)
   LLM_PROVIDER = openai
   LLM_API_KEY = sk-proj-... (from platform.openai.com/api-keys)
   LLM_MODEL = gpt-4o-mini
   GOOGLE_CLIENT_ID = (next step)
   GOOGLE_CLIENT_SECRET = (next step)
   GOOGLE_REDIRECT_URI = https://YOUR-VERCEL-URL.vercel.app/api/oauth/gmail/callback
   SEARCH_API_KEY = (optional, from serper.dev)
   NEXT_PUBLIC_APP_URL = https://YOUR-VERCEL-URL.vercel.app
   ```

3. Tap **Deploy**.

4. After deploy, open `https://YOUR-VERCEL-URL.vercel.app/api/health` — should return:
   ```json
   {"status":"ok","version":"1.0.0","db":"connected"}
   ```

   If `db: disconnected`, check `DATABASE_URL`.

---

## 3. Run Database Migrations

Vercel does not auto-run Prisma migrations. Do it from your phone via **GitHub Actions**:

1. In your fork, go to **Actions → Database Migrate** (if present) → Run workflow  
   OR use **Vercel CLI via browser terminal**: Use `https://github.dev` Codespace → Terminal:
   ```bash
   cd backend
   npx prisma migrate deploy
   ```

   Alternative phone-friendly: Install **Termux** from F-Droid, then:
   ```bash
   pkg install nodejs git
   git clone https://github.com/YOUR_USERNAME/apex.git
   cd apex/backend
   npm install
   echo 'DATABASE_URL="your-url"' > .env
   npx prisma migrate deploy
   ```

   Expected tables: `User`, `Session`, `Conversation`, `Task`, `ToolCall`, `Approval`, `Memory`, `File`, `OAuthToken`.

---

## 4. Configure Google OAuth (Gmail + Calendar)

Full guide: **[OAUTH_SETUP.md](./OAUTH_SETUP.md)** — summary:

1. **console.cloud.google.com** → New Project `APEX` → Enable **Gmail API** + **Google Calendar API** + **People API**
2. **OAuth consent screen** → External → Add scopes: `gmail.readonly`, `gmail.send`, `calendar`, `calendar.events`
3. **Credentials → Create OAuth Client ID → Web Application**
   - Authorized redirect URIs:
     ```
     https://YOUR-VERCEL-URL.vercel.app/api/oauth/gmail/callback
     https://YOUR-VERCEL-URL.vercel.app/api/oauth/calendar/callback
     ```
4. Copy Client ID/Secret → paste into Vercel Env Vars → **Redeploy**

Test: `https://YOUR-VERCEL-URL.vercel.app/api/oauth/gmail` → should redirect to Google.

---

## 5. Connect Android App

1. Build APK via GitHub Actions (see README) and install.
2. Open APEX → **Settings → Backend URL** → enter `https://YOUR-VERCEL-URL.vercel.app` → Save → Test connection (green dot)
3. **Register** → Login → Dashboard should show “APEX Online”

You can also hardcode URL at build time:
```bash
echo 'BACKEND_URL=https://YOUR-VERCEL-URL.vercel.app' > android/local.properties
# then rebuild via Actions
```

---

## 6. Update Backend Later

- Push to `main` → Vercel auto-deploys
- Or Vercel Dashboard → Deployments → Redeploy

---

## 7. Health Check

- `GET /api/health` → DB, LLM, OAuth status
- App shows **Backend unavailable** banner if `/api/health` fails — check Vercel logs.

---

## 8. Production Checklist

- [ ] Change `JWT_SECRET` and `ENCRYPTION_KEY` from examples
- [ ] Enable Supabase Row Level Security (Prisma handles per-user isolation, but enable RLS as defense-in-depth)
- [ ] Restrict CORS: set `FRONTEND_URL` to your Vercel URL + `https://app.apex` (Android)
- [ ] Rotate LLM keys monthly
- [ ] Enable Vercel Analytics + Sentry for errors

