# Keep serialization
-keep class com.apex.agent.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn org.bouncycastle.**
