package com.apex.agent.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.apex.agent.ui.screens.*

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val DASHBOARD = "dashboard"
    const val CHAT = "chat"
    const val VOICE = "voice"
    const val TASKS = "tasks"
    const val HISTORY = "history"
    const val APPROVALS = "approvals"
    const val GMAIL = "gmail"
    const val CALENDAR = "calendar"
    const val FILES = "files"
    const val MEMORY = "memory"
    const val SETTINGS = "settings"
}

@Composable
fun ApexNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) { SplashScreen(navController) }
        composable(Routes.LOGIN) { LoginScreen(navController) }
        composable(Routes.REGISTER) { RegisterScreen(navController) }
        composable(Routes.DASHBOARD) { DashboardScreen(navController) }
        composable(Routes.CHAT) { ChatScreen(navController) }
        composable(Routes.VOICE) { VoiceScreen(navController) }
        composable(Routes.TASKS) { TasksScreen(navController) }
        composable(Routes.HISTORY) { HistoryScreen(navController) }
        composable(Routes.APPROVALS) { ApprovalsScreen(navController) }
        composable(Routes.GMAIL) { GmailScreen(navController) }
        composable(Routes.CALENDAR) { CalendarScreen(navController) }
        composable(Routes.FILES) { FilesScreen(navController) }
        composable(Routes.MEMORY) { MemoryScreen(navController) }
        composable(Routes.SETTINGS) { SettingsScreen(navController) }
    }
}
