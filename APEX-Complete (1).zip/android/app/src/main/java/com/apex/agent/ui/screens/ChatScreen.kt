package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.data.remote.ChatRequest
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
data class ChatMsg(val role: String, val content: String, val isStreaming: Boolean = false)
@Composable
fun ChatScreen(navController: NavController) {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<ChatMsg>()) }
    var isTyping by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack)) {
        TopAppBar(title = { Text("APEX Chat", color = ApexCyan) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = ApexNavy))
        LazyColumn(modifier = Modifier.weight(1f).padding(12.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                Card(colors = CardDefaults.cardColors(containerColor = if (msg.role=="user") ApexBlue else ApexCard), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(if (msg.role=="user") "You" else "APEX", style = MaterialTheme.typography.labelSmall, color = ApexGray)
                        Text(msg.content, color = ApexWhite)
                        if (msg.isStreaming) { Spacer(Modifier.height(4.dp)); LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ApexCyan) }
                    }
                }
            }
            if (isTyping) item { Text("APEX is thinking...", color = ApexGray) }
        }
        Row(modifier = Modifier.fillMaxWidth().background(ApexNavy).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Ask APEX anything...") }, maxLines = 4)
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                if (input.isBlank()) return@IconButton
                val userMsg = input; input = ""; messages = messages + ChatMsg("user", userMsg)
                scope.launch {
                    isTyping = true
                    try {
                        // Try task mode for commands that look like tasks
                        val isTask = userMsg.lowercase().contains("research") || userMsg.lowercase().contains("check") || userMsg.lowercase().contains("find") || userMsg.lowercase().contains("organize")
                        val res = ApexApplication.instance.apiService.chat(ChatRequest(message = userMsg, mode = if (isTask) "task" else "chat"))
                        if (res.isSuccessful) {
                            val body = res.body()?.string() ?: ""
                            if (body.contains("taskId")) {
                                messages = messages + ChatMsg("assistant", "Task created — track progress in Active Tasks. Response: $body")
                            } else {
                                // Try to parse SSE or plain
                                messages = messages + ChatMsg("assistant", body.take(2000))
                            }
                        } else {
                            // Fallback: direct LLM via mock
                            messages = messages + ChatMsg("assistant", "APEX (offline): I received '${userMsg}'. Backend returned ${res.code()}. Check backend URL in Settings.")
                        }
                    } catch (e: Exception) {
                        messages = messages + ChatMsg("assistant", "Error: ${e.message}. Check backend connection.")
                    } finally { isTyping = false }
                }
            }) { Icon(Icons.Filled.Send, contentDescription = "Send", tint = ApexCyan) }
        }
    }
}
