package com.apex.agent.ui.screens
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun GmailScreen(navController: NavController) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("Checking...") }
    var connected by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        try { val r = ApexApplication.instance.apiService.gmailStatus(); connected = r.isSuccessful && r.body()?.connected==true; status = if (connected) "Connected: ${r.body()?.email}" else "Not connected — tap Connect" } catch (e:Exception){ status="Error: ${e.message}" }
    }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Gmail", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(8.dp))
        Text(status, color = if (connected) ApexSuccess else ApexGray)
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            // Open OAuth URL with JWT state
            val token = ApexApplication.instance.secureStorage.getAccessToken() ?: ""
            val url = "${ApexApplication.instance.backendUrl.trimEnd('/')}/api/oauth/gmail?state=$token"
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }) { Text(if (connected) "Reconnect Gmail" else "Connect Gmail") }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            scope.launch {
                try {
                    val r = ApexApplication.instance.apiService.executeTool(mapOf("toolName" to "gmail_list", "input" to mapOf("query" to "newer_than:7d", "maxResults" to 5)))
                    status = if (r.isSuccessful) "Gmail list: ${r.body()}" else "Failed ${r.code()}"
                } catch (e:Exception){ status = e.message ?: "error" }
            }
        }) { Text("Test: List recent emails") }
    }
}
