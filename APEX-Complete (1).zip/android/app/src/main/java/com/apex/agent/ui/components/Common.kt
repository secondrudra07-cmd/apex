package com.apex.agent.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.apex.agent.ui.theme.ApexBlack
import com.apex.agent.ui.theme.ApexBlue
import com.apex.agent.ui.theme.ApexCyan
import com.apex.agent.ui.theme.ApexNavy

@Composable
fun ApexCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ApexNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) { Column(modifier = Modifier.padding(16.dp), content = content) }
}

@Composable
fun ApexGradientButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ApexCyan)
    ) { Text(text, color = ApexBlack) }
}

@Composable
fun ApexTopBar(title: String) {
    Box(
        modifier = Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(ApexNavy, ApexBlack))).padding(16.dp),
        contentAlignment = Alignment.CenterStart
    ) { Text(title, style = MaterialTheme.typography.titleLarge, color = ApexCyan) }
}
