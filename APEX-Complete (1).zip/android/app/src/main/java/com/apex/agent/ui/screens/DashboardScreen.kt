package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.navigation.Routes
import com.apex.agent.ui.components.ApexCard
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(navController: NavController) {
    var health by remember { mutableStateOf("Checking...") }
    var backendOk by remember { mutableStateOf(false) }
    var tasks by remember { mutableStateOf<List<com.apex.agent.data.remote.TaskDto>>(emptyList()) }
    var approvals by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        launch {
            try { val r = ApexApplication.instance.apiService.health(); health = if (r.isSuccessful) "${r.body()?.status} v${r.body()?.version}" else "Unavailable ${r.code()}"; backendOk = r.isSuccessful } catch (e: Exception){ health = "Unavailable: ${e.message}"; backendOk=false }
        }
        launch {
            try { val r = ApexApplication.instance.apiService.tasks(); if (r.isSuccessful) tasks = r.body()?.tasks ?: emptyList() } catch (_:Exception){}
        }
        launch {
            try { val r = ApexApplication.instance.apiService.approvals(); if (r.isSuccessful) approvals = r.body()?.get("approvals")?.size ?: 0 } catch (_:Exception){}
        }
    }
    LazyColumn(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            ApexCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SmartToy, contentDescription = null, tint = ApexCyan)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("APEX Status", color = ApexCyan, style = MaterialTheme.typography.titleLarge)
                        Text(if (backendOk) "Online • $health" else "Offline • $health", color = if (backendOk) ApexSuccess else ApexError)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                QuickStat("Tasks", tasks.size.toString(), Icons.Filled.Task) { navController.navigate(Routes.TASKS) }
                QuickStat("Approvals", approvals.toString(), Icons.Filled.Approval) { navController.navigate(Routes.APPROVALS) }
            }
        }
        item { Text("Quick Commands", color = ApexWhite, style = MaterialTheme.typography.titleMedium) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val quicks = listOf("Check my Gmail","Research AI news","Find deadlines","Organize documents","Create study plan","Remind me tomorrow")
                items(quicks) { q ->
                    AssistChip(onClick = { navController.navigate(Routes.CHAT) }, label = { Text(q) })
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                DashboardIcon("Chat", Icons.Filled.Chat) { navController.navigate(Routes.CHAT) }
                DashboardIcon("Voice", Icons.Filled.Mic) { navController.navigate(Routes.VOICE) }
                DashboardIcon("Files", Icons.Filled.Folder) { navController.navigate(Routes.FILES) }
                DashboardIcon("Settings", Icons.Filled.Settings) { navController.navigate(Routes.SETTINGS) }
            }
        }
        item { Text("Recent Activity", color = ApexWhite, style = MaterialTheme.typography.titleMedium) }
        if (tasks.isEmpty()) item { Text("No tasks yet — try chatting with APEX", color = ApexGray) }
        items(tasks.take(5)) { t ->
            ApexCard(modifier = Modifier.fillMaxWidth().clickable{ navController.navigate(Routes.TASKS) }) {
                Text(t.command, color = ApexWhite, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Text("${t.status} • ${t.progress}%", color = ApexGray, style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(progress = { t.progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top=8.dp), color = ApexCyan)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { navController.navigate(Routes.GMAIL) }) { Text("Gmail") }
                Button(onClick = { navController.navigate(Routes.CALENDAR) }) { Text("Calendar") }
                Button(onClick = { navController.navigate(Routes.MEMORY) }) { Text("Memory") }
                Button(onClick = { navController.navigate(Routes.HISTORY) }) { Text("History") }
            }
        }
    }
}
@Composable
fun QuickStat(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit) {
    Card(modifier = Modifier.width(160.dp).clickable(onClick=onClick), colors = CardDefaults.cardColors(containerColor = ApexNavy)) {
        Column(Modifier.padding(12.dp)) { Icon(icon, null, tint = ApexCyan); Text(value, color = ApexWhite, style = MaterialTheme.typography.titleLarge); Text(title, color = ApexGray) }
    }
}
@Composable
fun DashboardIcon(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick:()->Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick=onClick).padding(8.dp)) {
        Icon(icon, contentDescription = label, tint = ApexCyan, modifier = Modifier.size(32.dp))
        Text(label, color = ApexWhite, style = MaterialTheme.typography.bodySmall)
    }
}
