package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.navigation.Routes
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun SettingsScreen(navController: NavController) {
    var backendUrl by remember { mutableStateOf(ApexApplication.instance.secureStorage.getBackendUrl() ?: ApexApplication.instance.backendUrl) }
    var health by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(16.dp))
        Text("Backend URL", color = ApexWhite)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://your-backend.vercel.app") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                ApexApplication.instance.secureStorage.saveBackendUrl(backendUrl.trim())
                ApexApplication.instance.recreateApiService()
                scope.launch {
                    try { val r = ApexApplication.instance.apiService.health(); health = if (r.isSuccessful) "Connected ✓ ${r.body()?.version}" else "Failed ${r.code()}" } catch(e:Exception){ health = "Error ${e.message}" }
                }
            }) { Text("Save & Test") }
            OutlinedButton(onClick = {
                scope.launch { try { val r = ApexApplication.instance.apiService.health(); health = r.body()?.status ?: "${r.code()}" } catch(e:Exception){ health = e.message ?: "err"} }
            ) { Text("Health Check") }
        }
        if (health.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(health, color = ApexSuccess) }
        Spacer(Modifier.height(24.dp))
        Text("Account", color = ApexWhite)
        Text(ApexApplication.instance.secureStorage.getUserEmail() ?: "Unknown", color = ApexGray)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { ApexApplication.instance.secureStorage.clear(); navController.navigate(Routes.LOGIN){ popUpTo(0){inclusive=true} } }, colors = ButtonDefaults.buttonColors(containerColor = ApexError)) { Text("Log Out") }
        Spacer(Modifier.height(24.dp))
        Text("APEX v1.0.0 • Native Android • Kotlin + Compose", color = ApexGray, style = MaterialTheme.typography.bodySmall)
        Text("Secrets never in APK — backend only", color = ApexGray, style = MaterialTheme.typography.bodySmall)
    }
}
