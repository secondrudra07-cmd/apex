package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.navigation.Routes
import com.apex.agent.ui.components.ApexGradientButton
import com.apex.agent.ui.theme.ApexBlack
import com.apex.agent.ui.theme.ApexNavy
import kotlinx.coroutines.launch
@Composable
fun LoginScreen(navController: NavController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Welcome to APEX", style = MaterialTheme.typography.headlineLarge, color = com.apex.agent.ui.theme.ApexCyan)
        Spacer(Modifier.height(8.dp))
        Text("Sign in to continue", color = com.apex.agent.ui.theme.ApexGray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
        if (error != null) { Spacer(Modifier.height(8.dp)); Text(error!!, color = com.apex.agent.ui.theme.ApexError) }
        Spacer(Modifier.height(16.dp))
        ApexGradientButton(text = if (loading) "Signing in..." else "Login", modifier = Modifier.fillMaxWidth(), enabled = !loading) {
            scope.launch {
                loading = true; error = null
                try {
                    val res = ApexApplication.instance.apiService.login(com.apex.agent.data.remote.LoginRequest(email.trim(), password))
                    if (res.isSuccessful && res.body() != null) {
                        val body = res.body()!!
                        ApexApplication.instance.secureStorage.saveTokens(body.token, body.refreshToken)
                        ApexApplication.instance.secureStorage.saveUserEmail(body.user.email)
                        navController.navigate(Routes.DASHBOARD) { popUpTo(Routes.LOGIN){inclusive=true} }
                    } else error = res.errorBody()?.string() ?: "Login failed: ${res.code()}"
                } catch (e: Exception) { error = e.message } finally { loading = false }
            }
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { navController.navigate(Routes.REGISTER) }) { Text("Create account", color = com.apex.agent.ui.theme.ApexCyan) }
        Spacer(Modifier.height(12.dp))
        Text("Backend: ${ApexApplication.instance.backendUrl}", style = MaterialTheme.typography.bodySmall, color = com.apex.agent.ui.theme.ApexGray)
    }
}
