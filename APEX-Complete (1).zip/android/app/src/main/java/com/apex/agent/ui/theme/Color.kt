package com.apex.agent.ui.theme

import androidx.compose.ui.graphics.Color

val ApexBlack = Color(0xFF020617)
val ApexNavy = Color(0xFF0F172A)
val ApexNavyLight = Color(0xFF1E293B)
val ApexCyan = Color(0xFF22D3EE)
val ApexBlue = Color(0xFF3B82F6)
val ApexDarkCyan = Color(0xFF0891B2)
val ApexWhite = Color(0xFFF1F5F9)
val ApexGray = Color(0xFF94A3B8)
val ApexCard = Color(0xFF1E293B)
val ApexSuccess = Color(0xFF10B981)
val ApexWarning = Color(0xFFF59E0B)
val ApexError = Color(0xFFEF4444)
