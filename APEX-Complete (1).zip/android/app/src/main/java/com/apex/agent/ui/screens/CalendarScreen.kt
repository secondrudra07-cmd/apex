package com.apex.agent.ui.screens
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun CalendarScreen(navController: NavController) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("Checking...") }
    var connected by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        try { val r = ApexApplication.instance.apiService.calendarStatus(); connected = r.isSuccessful && r.body()?.connected==true; status = if (connected) "Connected" else "Not connected" } catch (e:Exception){ status="Error ${e.message}"}
    }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Calendar", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(8.dp))
        Text(status, color = if (connected) ApexSuccess else ApexGray)
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            val token = ApexApplication.instance.secureStorage.getAccessToken() ?: ""
            val url = "${ApexApplication.instance.backendUrl.trimEnd('/')}/api/oauth/calendar?state=$token"
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }) { Text(if (connected) "Reconnect Calendar" else "Connect Calendar") }
        Spacer(Modifier.height(12.dp))
        var scope = rememberCoroutineScope()
        Button(onClick = { scope.launch {
            try { val r = ApexApplication.instance.apiService.executeTool(mapOf("toolName" to "calendar_list", "input" to mapOf("maxResults" to 5))); status = r.body().toString().take(500) } catch(e:Exception){ status = e.message ?: "err"}
        }}) { Text("Test: List events") }
    }
}
