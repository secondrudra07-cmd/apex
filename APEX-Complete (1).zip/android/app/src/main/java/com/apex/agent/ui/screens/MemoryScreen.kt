package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.data.remote.MemoryDto
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun MemoryScreen(navController: NavController) {
    var memories by remember { mutableStateOf<List<MemoryDto>>(emptyList()) }
    var key by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    suspend fun load(){ try { val r = ApexApplication.instance.apiService.memories(); if (r.isSuccessful) memories = r.body()?.get("memories") ?: emptyList() } catch(_:Exception){} }
    LaunchedEffect(Unit){ load() }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Memory", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Text("APEX remembers what you approve.", color = ApexGray, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("Key") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text("Value") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { scope.launch { try { ApexApplication.instance.apiService.createMemory(mapOf("key" to key, "value" to value)); key=""; value=""; load() } catch(_:Exception){} } }) { Text("Save Memory") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(memories) { m -> Card(colors = CardDefaults.cardColors(containerColor = ApexNavy)) { Column(Modifier.padding(12.dp)) { Text(m.key, color = ApexCyan); Text(m.value, color = ApexWhite) } } }
            if (memories.isEmpty()) item { Text("No memories yet", color = ApexGray) }
        }
    }
}
