package com.apex.agent.ui.screens
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.data.remote.FileDto
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
@Composable
fun FilesScreen(navController: NavController) {
    val ctx = LocalContext.current
    var files by remember { mutableStateOf<List<FileDto>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    suspend fun load(){ try { val r = ApexApplication.instance.apiService.files(); if (r.isSuccessful) files = r.body()?.get("files") ?: emptyList() } catch(_:Exception){} }
    LaunchedEffect(Unit){ load() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            try {
                val input = ctx.contentResolver.openInputStream(uri) ?: return@launch
                val bytes = input.readBytes(); input.close()
                val part = MultipartBody.Part.createFormData("file", uri.lastPathSegment ?: "upload.pdf", bytes.toRequestBody("application/octet-stream".toMediaTypeOrNull()))
                val r = ApexApplication.instance.apiService.uploadFile(part)
                msg = if (r.isSuccessful) "Uploaded ✓" else "Upload failed ${r.code()}"
                load()
            } catch (e:Exception){ msg = e.message ?: "err" }
        }
    }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Files", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(8.dp))
        if (msg.isNotBlank()) Text(msg, color = ApexSuccess)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { picker.launch("*/*") }) { Text("Upload Document") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files) { f -> Card(colors = CardDefaults.cardColors(containerColor = ApexNavy)) { Column(Modifier.padding(12.dp)) { Text(f.fileName, color = ApexWhite); Text("${f.mimeType} • ${f.size} bytes", color = ApexGray, style = MaterialTheme.typography.bodySmall) } } }
            if (files.isEmpty()) item { Text("No files yet", color = ApexGray) }
        }
    }
}
