package com.apex.agent.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "tasks_cache")
data class CachedTask(
    @PrimaryKey val id: String,
    val command: String,
    val status: String,
    val progress: Int,
    val result: String?,
    val createdAt: String
)

@Entity(tableName = "settings")
data class Setting(@PrimaryKey val key: String, val value: String)

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks_cache ORDER BY createdAt DESC")
    suspend fun getAll(): List<CachedTask>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: CachedTask)
    @Query("DELETE FROM tasks_cache")
    suspend fun clear()
}

@Dao
interface SettingsDao {
    @Query("SELECT value FROM settings WHERE `key` = :key")
    suspend fun get(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(setting: Setting)
}

@Database(entities = [CachedTask::class, Setting::class], version = 1, exportSchema = false)
abstract class ApexDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun settingsDao(): SettingsDao
}
