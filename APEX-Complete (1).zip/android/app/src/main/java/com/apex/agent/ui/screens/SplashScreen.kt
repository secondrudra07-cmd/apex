package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.navigation.Routes
import com.apex.agent.ui.theme.ApexBlack
import com.apex.agent.ui.theme.ApexCyan
import com.apex.agent.ui.theme.ApexNavy
import kotlinx.coroutines.delay
@Composable
fun SplashScreen(navController: NavController) {
    LaunchedEffect(Unit) {
        delay(1200)
        val app = ApexApplication.instance
        if (app.secureStorage.isLoggedIn()) navController.navigate(Routes.DASHBOARD) { popUpTo(Routes.SPLASH){inclusive=true} }
        else navController.navigate(Routes.LOGIN) { popUpTo(Routes.SPLASH){inclusive=true} }
    }
    Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(ApexNavy, ApexBlack))), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("APEX", fontSize = 48.sp, fontWeight = FontWeight.Black, color = ApexCyan)
            Text("Autonomous Personal AI", fontSize = 14.sp, color = ApexCyan.copy(alpha=0.7f))
        }
    }
}
