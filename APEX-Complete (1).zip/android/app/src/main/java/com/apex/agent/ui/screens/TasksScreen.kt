package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.data.remote.TaskDto
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun TasksScreen(navController: NavController) {
    var tasks by remember { mutableStateOf<List<TaskDto>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        try { val r = ApexApplication.instance.apiService.tasks(); if (r.isSuccessful) tasks = r.body()?.tasks ?: emptyList() } catch (_:Exception){} finally { loading=false }
    }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Active Tasks", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(12.dp))
        if (loading) { LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = ApexCyan) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tasks) { t ->
                Card(colors = CardDefaults.cardColors(containerColor = ApexNavy), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(t.command, color = ApexWhite)
                        Spacer(Modifier.height(4.dp))
                        Text("Status: ${t.status} • ${t.progress}%", color = ApexGray, style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(progress = { t.progress/100f }, modifier = Modifier.fillMaxWidth().padding(top=8.dp))
                        if (t.status=="running" || t.status=="pending") {
                            Spacer(Modifier.height(8.dp))
                            Row {
                                Button(onClick = { scope.launch { try { ApexApplication.instance.apiService.cancelTask(t.id) } catch(_:Exception){} } }) { Text("Cancel") }
                            }
                        }
                        if (!t.result.isNullOrBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(t.result.take(500), color = ApexWhite, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (tasks.isEmpty()) item { Text("No active tasks", color = ApexGray) }
        }
    }
}
