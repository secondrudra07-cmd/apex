package com.apex.agent.data.remote

data class LoginRequest(val email: String, val password: String)
data class RegisterRequest(val email: String, val password: String, val name: String? = null)
data class AuthResponse(val user: UserDto, val token: String, val refreshToken: String)
data class UserDto(val id: String, val email: String, val name: String?)
data class HealthResponse(val status: String, val version: String, val db: String, val checks: Map<String,String>?)

data class ChatRequest(val message: String, val conversationId: String? = null, val mode: String? = null)
data class ChatStreamChunk(val content: String?, val done: Boolean?, val error: String?)

data class TaskDto(
    val id: String, val command: String, val status: String, val progress: Int,
    val plan: Any?, val result: String?, val logs: Any?, val createdAt: String, val updatedAt: String,
    val toolCalls: List<ToolCallDto>? = null, val approvals: List<ApprovalDto>? = null
)
data class ToolCallDto(val id: String, val toolName: String, val input: Any?, val output: Any?, val status: String)
data class ApprovalDto(val id: String, val toolName: String, val action: String, val consequences: String, val status: String, val createdAt: String)
data class TaskListResponse(val tasks: List<TaskDto>)
data class OAuthStatus(val connected: Boolean, val email: String?, val scope: String?)
data class FileDto(val id: String, val fileName: String, val mimeType: String?, val size: Int?, val createdAt: String)
data class MemoryDto(val id: String, val key: String, val value: String, val category: String?)
