package com.apex.agent.util

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureStorage(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "apex_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveTokens(accessToken: String, refreshToken: String) {
        prefs.edit().putString("access_token", accessToken).putString("refresh_token", refreshToken).apply()
    }
    fun getAccessToken(): String? = prefs.getString("access_token", null)
    fun getRefreshToken(): String? = prefs.getString("refresh_token", null)
    fun saveBackendUrl(url: String) { prefs.edit().putString("backend_url", url).apply() }
    fun getBackendUrl(): String? = prefs.getString("backend_url", null)
    fun saveUserEmail(email: String) { prefs.edit().putString("user_email", email).apply() }
    fun getUserEmail(): String? = prefs.getString("user_email", null)
    fun clear() { prefs.edit().clear().apply() }
    fun isLoggedIn(): Boolean = getAccessToken() != null
}
