package com.apex.agent.data.remote

import com.apex.agent.util.SecureStorage
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val storage: SecureStorage) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = storage.getAccessToken()
        val req = chain.request().newBuilder().apply {
            if (token != null) header("Authorization", "Bearer $token")
            header("Content-Type", "application/json")
        }.build()
        return chain.proceed(req)
    }
}
