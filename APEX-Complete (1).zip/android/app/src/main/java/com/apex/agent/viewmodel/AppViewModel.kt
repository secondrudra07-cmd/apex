package com.apex.agent.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.apex.agent.ApexApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
class AppViewModel : ViewModel() {
    private val _health = MutableStateFlow("Checking...")
    val health: StateFlow<String> = _health
    init { viewModelScope.launch { try { val r = ApexApplication.instance.apiService.health(); _health.value = if (r.isSuccessful) "Online" else "Backend ${r.code()}" } catch (e: Exception){ _health.value = "Offline: ${e.message}" } } }
}
