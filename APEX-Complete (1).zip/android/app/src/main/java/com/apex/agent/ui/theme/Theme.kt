package com.apex.agent.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ApexColors(
    val background: Color,
    val surface: Color,
    val card: Color,
    val primary: Color,
    val primaryVariant: Color,
    val onBackground: Color,
    val onSurface: Color,
    val muted: Color,
    val success: Color,
    val warning: Color,
    val error: Color
)

val LocalApexColors = staticCompositionLocalOf {
    ApexColors(ApexBlack, ApexNavy, ApexCard, ApexCyan, ApexBlue, ApexWhite, ApexWhite, ApexGray, ApexSuccess, ApexWarning, ApexError)
}

private val DarkScheme = darkColorScheme(
    primary = ApexCyan,
    secondary = ApexBlue,
    background = ApexBlack,
    surface = ApexNavy,
    error = ApexError,
    onPrimary = ApexBlack,
    onBackground = ApexWhite,
    onSurface = ApexWhite
)

object ApexTheme {
    val colors: ApexColors
        @Composable get() = LocalApexColors.current
    val shapes = androidx.compose.material3.Shapes(
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(24.dp)
    )
}

@Composable
fun ApexTheme(content: @Composable () -> Unit) {
    val apexColors = ApexColors(
        background = ApexBlack, surface = ApexNavy, card = ApexCard,
        primary = ApexCyan, primaryVariant = ApexBlue, onBackground = ApexWhite,
        onSurface = ApexWhite, muted = ApexGray, success = ApexSuccess, warning = ApexWarning, error = ApexError
    )
    CompositionLocalProvider(LocalApexColors provides apexColors) {
        MaterialTheme(colorScheme = DarkScheme, typography = Typography(
            headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif),
            titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
            bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp)
        ), content = content)
    }
}
