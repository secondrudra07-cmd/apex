package com.apex.agent.data.remote

import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    @GET("api/health")
    suspend fun health(): Response<HealthResponse>

    @POST("api/auth/register")
    suspend fun register(@Body req: RegisterRequest): Response<AuthResponse>

    @POST("api/auth/login")
    suspend fun login(@Body req: LoginRequest): Response<AuthResponse>

    @GET("api/auth/me")
    suspend fun me(): Response<Map<String, Any>>

    @POST("api/chat")
    @Headers("Accept: text/event-stream")
    suspend fun chat(@Body req: ChatRequest): Response<ResponseBody>

    @GET("api/tasks")
    suspend fun tasks(): Response<TaskListResponse>

    @POST("api/tasks")
    suspend fun createTask(@Body body: Map<String, String>): Response<Map<String, Any>>

    @GET("api/tasks/{id}")
    suspend fun task(@Path("id") id: String): Response<Map<String, Any>>

    @POST("api/tasks/{id}/cancel")
    suspend fun cancelTask(@Path("id") id: String): Response<Map<String, Any>>

    @GET("api/approvals")
    suspend fun approvals(): Response<Map<String, List<ApprovalDto>>>

    @POST("api/approvals/{id}/approve")
    suspend fun approve(@Path("id") id: String, @Body body: Map<String, Boolean>): Response<Map<String, Any>>

    @GET("api/oauth/gmail/status")
    suspend fun gmailStatus(): Response<OAuthStatus>

    @GET("api/oauth/calendar/status")
    suspend fun calendarStatus(): Response<OAuthStatus>

    @POST("api/research/search")
    suspend fun research(@Body body: Map<String, String>): Response<Map<String, Any>>

    @Multipart
    @POST("api/files/upload")
    suspend fun uploadFile(@Part file: MultipartBody.Part): Response<Map<String, Any>>

    @GET("api/files")
    suspend fun files(): Response<Map<String, List<FileDto>>>

    @GET("api/memory")
    suspend fun memories(): Response<Map<String, List<MemoryDto>>>

    @POST("api/memory")
    suspend fun createMemory(@Body body: Map<String, String>): Response<Map<String, Any>>

    @POST("api/tools/execute")
    suspend fun executeTool(@Body body: Map<String, Any>): Response<Map<String, Any>>
}
