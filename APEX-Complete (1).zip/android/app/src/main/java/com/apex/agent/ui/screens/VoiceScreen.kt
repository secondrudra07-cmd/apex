package com.apex.agent.ui.screens
import android.Manifest
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ui.theme.*
import java.util.Locale
@Composable
fun VoiceScreen(navController: NavController) {
    val ctx = LocalContext.current
    var transcript by remember { mutableStateOf("") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var permissionGranted by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> permissionGranted = granted }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        transcript = data?.firstOrNull() ?: ""
    }
    DisposableEffect(Unit) {
        val t = TextToSpeech(ctx) { status -> if (status == TextToSpeech.SUCCESS) t?.language = Locale.US }
        tts = t
        onDispose { t.shutdown() }
    }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Voice Assistant", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(12.dp))
        Text(transcript.ifBlank { "Tap mic and speak" }, color = ApexWhite, modifier = Modifier.padding(16.dp))
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (!permissionGranted) permLauncher.launch(Manifest.permission.RECORD_AUDIO)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toString())
            }
            try { speechLauncher.launch(intent) } catch (e: Exception) { transcript = "Speech not available: ${e.message}" }
        }, modifier = Modifier.size(80.dp), colors = ButtonDefaults.buttonColors(containerColor = ApexCyan)) {
            Icon(Icons.Filled.Mic, contentDescription = "Mic", modifier = Modifier.size(32.dp), tint = ApexBlack)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { tts?.speak(transcript.ifBlank { "Hello, I am APEX, your personal AI assistant" }, TextToSpeech.QUEUE_FLUSH, null, "apex-tts") }) {
            Text("Speak")
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { navController.popBackStack() }) { Text("Back") }
    }
}
