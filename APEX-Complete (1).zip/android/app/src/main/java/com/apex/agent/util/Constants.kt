package com.apex.agent.util

object Constants {
    const val PREFS_BACKEND_URL = "backend_url"
    const val DEFAULT_BACKEND_URL = "https://apex-backend.vercel.app"
}
