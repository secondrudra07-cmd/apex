package com.apex.agent

import android.app.Application
import androidx.room.Room
import com.apex.agent.data.local.ApexDatabase
import com.apex.agent.data.remote.ApiService
import com.apex.agent.data.remote.AuthInterceptor
import com.apex.agent.util.SecureStorage
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class ApexApplication : Application() {
    companion object {
        lateinit var instance: ApexApplication
            private set
        var backendUrl: String = BuildConfig.BACKEND_URL
    }

    lateinit var secureStorage: SecureStorage
    lateinit var database: ApexDatabase
    lateinit var apiService: ApiService

    override fun onCreate() {
        super.onCreate()
        instance = this
        secureStorage = SecureStorage(this)
        backendUrl = secureStorage.getBackendUrl() ?: BuildConfig.BACKEND_URL

        database = Room.databaseBuilder(this, ApexDatabase::class.java, "apex.db")
            .fallbackToDestructiveMigration()
            .build()

        apiService = createApiService()
    }

    fun recreateApiService() {
        backendUrl = secureStorage.getBackendUrl() ?: BuildConfig.BACKEND_URL
        apiService = createApiService()
    }

    private fun createApiService(): ApiService {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        val client = OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(secureStorage))
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
        return Retrofit.Builder()
            .baseUrl(backendUrl.trimEnd('/') + "/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
            .create(ApiService::class.java)
    }
}
