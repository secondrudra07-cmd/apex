package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.navigation.Routes
import com.apex.agent.ui.components.ApexGradientButton
import com.apex.agent.ui.theme.ApexBlack
import kotlinx.coroutines.launch
@Composable
fun RegisterScreen(navController: NavController) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Create APEX Account", style = MaterialTheme.typography.headlineLarge, color = com.apex.agent.ui.theme.ApexCyan)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password (min 8)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (error != null) { Spacer(Modifier.height(8.dp)); Text(error!!, color = com.apex.agent.ui.theme.ApexError) }
        Spacer(Modifier.height(16.dp))
        ApexGradientButton("Register", modifier = Modifier.fillMaxWidth(), enabled = !loading) {
            scope.launch {
                loading = true
                try {
                    val res = ApexApplication.instance.apiService.register(com.apex.agent.data.remote.RegisterRequest(email.trim(), password, name.ifBlank{null}))
                    if (res.isSuccessful && res.body()!=null) {
                        val b = res.body()!!
                        ApexApplication.instance.secureStorage.saveTokens(b.token, b.refreshToken)
                        navController.navigate(Routes.DASHBOARD){ popUpTo(Routes.REGISTER){inclusive=true} }
                    } else error = res.errorBody()?.string() ?: "Failed ${res.code()}"
                } catch (e:Exception){ error = e.message } finally { loading=false }
            }
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { navController.popBackStack() }) { Text("Back to Login") }
    }
}
