package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.data.remote.ApprovalDto
import com.apex.agent.ui.theme.*
import kotlinx.coroutines.launch
@Composable
fun ApprovalsScreen(navController: NavController) {
    var approvals by remember { mutableStateOf<List<ApprovalDto>>(emptyList()) }
    val scope = rememberCoroutineScope()
    suspend fun load() { try { val r = ApexApplication.instance.apiService.approvals(); if (r.isSuccessful) approvals = r.body()?.get("approvals") ?: emptyList() } catch(_:Exception){} }
    LaunchedEffect(Unit){ load() }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Approval Requests", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Text("APEX will never send, delete, or publish without your approval.", color = ApexGray, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(approvals) { a ->
                Card(colors = CardDefaults.cardColors(containerColor = ApexNavy)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Action: ${a.toolName}", color = ApexCyan, style = MaterialTheme.typography.titleMedium)
                        Text(a.action, color = ApexWhite)
                        Spacer(Modifier.height(8.dp))
                        Text("Consequences:", color = ApexWarning, style = MaterialTheme.typography.labelMedium)
                        Text(a.consequences, color = ApexGray)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = { scope.launch { try { ApexApplication.instance.apiService.approve(a.id, mapOf("approved" to true)); load() } catch(_:Exception){} } }, colors = ButtonDefaults.buttonColors(containerColor = ApexSuccess)) { Text("Approve") }
                            OutlinedButton(onClick = { scope.launch { try { ApexApplication.instance.apiService.approve(a.id, mapOf("approved" to false)); load() } catch(_:Exception){} } }) { Text("Deny", color = ApexError) }
                        }
                    }
                }
            }
            if (approvals.isEmpty()) item { Text("No pending approvals", color = ApexGray) }
        }
    }
}
