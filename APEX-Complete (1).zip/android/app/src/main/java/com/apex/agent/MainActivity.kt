package com.apex.agent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.apex.agent.navigation.ApexNavHost
import com.apex.agent.ui.theme.ApexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ApexTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = ApexTheme.colors.background) {
                    ApexNavHost()
                }
            }
        }
    }
}
