package com.apex.agent.ui.screens
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.apex.agent.ApexApplication
import com.apex.agent.data.remote.TaskDto
import com.apex.agent.ui.theme.*
@Composable
fun HistoryScreen(navController: NavController) {
    var tasks by remember { mutableStateOf<List<TaskDto>>(emptyList()) }
    LaunchedEffect(Unit) { try { val r = ApexApplication.instance.apiService.tasks(); if (r.isSuccessful) tasks = r.body()?.tasks ?: emptyList() } catch (_:Exception){} }
    Column(modifier = Modifier.fillMaxSize().background(ApexBlack).padding(16.dp)) {
        Text("Task History", style = MaterialTheme.typography.headlineLarge, color = ApexCyan)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tasks) { t ->
                Card(colors = CardDefaults.cardColors(containerColor = ApexNavy)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(t.command, color = ApexWhite)
                        Text("${t.status} • ${t.createdAt.take(10)}", color = ApexGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
