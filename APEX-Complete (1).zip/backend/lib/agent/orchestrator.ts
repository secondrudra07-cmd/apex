import { prisma } from "../db";
import { chatCompletion, SYSTEM_PROMPT } from "../llm";
import { getTool, getToolsForLLM } from "../tools/registry";

// Sanitize untrusted content (emails, web) to prevent prompt injection
function sanitizeUntrusted(text: string): string {
  return text.replace(/```/g, "").slice(0, 8000);
}

export interface TaskPlan {
  steps: { id: string; description: string; tool?: string; status: "pending" | "running" | "completed" | "failed" | "awaiting_approval" }[];
}

export async function understandAndPlan(command: string): Promise<TaskPlan> {
  const prompt = `User command: "${sanitizeUntrusted(command)}"

Create a 2-6 step plan to fulfill this. Each step should be one tool call or analysis.
Return JSON only: {"steps":[{"id":"1","description":"...","tool":"tool_name or null"}]}
Available tools: gmail_list, gmail_read, calendar_list, calendar_create, web_search, web_fetch, file_list, file_analyze, code_generate, memory_write, memory_read, memory_reminder
If no tool needed, use tool: null (pure reasoning/report).
`;

  const raw = await chatCompletion({ messages: [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: prompt }] });
  try {
    const parsed = JSON.parse(raw);
    // Normalize
    return { steps: parsed.steps.map((s: any, i: number) => ({ id: String(i + 1), description: s.description, tool: s.tool || undefined, status: "pending" as const })) };
  } catch {
    // Fallback: single step
    return { steps: [{ id: "1", description: command, status: "pending" }] };
  }
}

export async function executeTask(taskId: string) {
  const task = await prisma.task.findUnique({ where: { id: taskId } });
  if (!task) throw new Error("Task not found");
  if (task.status === "cancelled") return;

  await prisma.task.update({ where: { id: taskId }, data: { status: "running", progress: 5 } });

  const plan = task.plan as unknown as TaskPlan | null;
  if (!plan || !plan.steps.length) {
    await prisma.task.update({ where: { id: taskId }, data: { status: "failed", result: "No plan generated" } });
    return;
  }

  const logs: any[] = (task.logs as any[]) || [];
  let stepIndex = 0;

  for (const step of plan.steps) {
    const current = await prisma.task.findUnique({ where: { id: taskId } });
    if (current?.status === "cancelled") { logs.push({ step: step.id, event: "cancelled" }); break; }

    step.status = "running";
    await prisma.task.update({ where: { id: taskId }, data: { plan: plan as any, progress: Math.round((stepIndex / plan.steps.length) * 80) + 5 } });
    logs.push({ step: step.id, description: step.description, tool: step.tool, status: "running", at: new Date().toISOString() });

    if (!step.tool) {
      // Pure reasoning step — generate via LLM
      try {
        const reasoning = await chatCompletion({ messages: [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: `Task step: ${step.description}. Provide concise output.` }] });
        await prisma.toolCall.create({ data: { taskId, toolName: "reasoning", input: { step: step.description }, output: { result: reasoning }, status: "success" } });
        step.status = "completed";
        logs.push({ step: step.id, result: reasoning.slice(0, 1000) });
      } catch (e: any) {
        step.status = "failed";
        logs.push({ step: step.id, error: e.message });
      }
    } else {
      const tool = getTool(step.tool);
      if (!tool) {
        step.status = "failed";
        logs.push({ step: step.id, error: `Unknown tool ${step.tool}` });
        continue;
      }

      // Validate permissions: consequential requires approval
      if (tool.requiresApproval) {
        // Create approval record, pause task
        await prisma.approval.create({
          data: {
            userId: task.userId,
            taskId,
            toolName: tool.name,
            action: `Execute ${tool.name} for step: ${step.description}`,
            consequences: `This tool is ${tool.category}. It may send emails, create events, or modify data.`,
            details: { step: step.description, input: {} },
            status: "pending",
          },
        });
        step.status = "awaiting_approval";
        await prisma.task.update({ where: { id: taskId }, data: { status: "awaiting_approval", plan: plan as any, logs: logs as any } });
        // Pause execution — will resume via /api/approvals/:id/approve
        return;
      }

      // Execute tool with retry
      let attempt = 0;
      let success = false;
      let output: any = null;
      let error: string | null = null;
      const toolCallId = (await prisma.toolCall.create({ data: { taskId, toolName: tool.name, input: { step: step.description }, status: "running" } })).id;

      while (attempt < 3 && !success) {
        try {
          // Tool input is derived from step description via LLM parameter mapping
          const paramPrompt = `Given step: "${step.description}", extract parameters for tool ${tool.name} with schema ${JSON.stringify(tool.parameters)}. Return JSON only.`;
          let toolInput: any = {};
          try {
            const paramRaw = await chatCompletion({ messages: [{ role: "user", content: paramPrompt }] });
            toolInput = JSON.parse(paramRaw);
          } catch { toolInput = {}; }

          // Sanitize tool input
          output = await tool.execute(toolInput, { userId: task.userId, taskId });
          if (output && output.success === false) throw new Error(output.error || "Tool reported failure");
          success = true;
          await prisma.toolCall.update({ where: { id: toolCallId }, data: { output, status: "success", endedAt: new Date() } });
          logs.push({ step: step.id, tool: tool.name, input: toolInput, output: JSON.stringify(output).slice(0, 2000), status: "success" });
        } catch (e: any) {
          attempt++;
          error = e.message;
          if (attempt >= 3) {
            await prisma.toolCall.update({ where: { id: toolCallId }, data: { error, status: "failed", endedAt: new Date() } });
            logs.push({ step: step.id, tool: tool.name, error, status: "failed" });
          } else {
            await new Promise(r => setTimeout(r, 500 * Math.pow(2, attempt)));
          }
        }
      }
      step.status = success ? "completed" : "failed";
    }

    stepIndex++;
    await prisma.task.update({ where: { id: taskId }, data: { plan: plan as any, logs: logs as any, progress: Math.round((stepIndex / plan.steps.length) * 80) + 5 } });
  }

  // Final report generation
  const finalPrompt = `Task command: "${task.command}"
Plan steps and logs: ${JSON.stringify(logs).slice(0, 6000)}
Generate a final structured report: summary, key findings, sources/dates if any, next steps. Be concise and professional.`;

  let finalReport = "";
  try {
    finalReport = await chatCompletion({ messages: [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: finalPrompt }] });
  } catch { finalReport = "Task completed. See logs for details."; }

  const allCompleted = plan.steps.every(s => s.status === "completed" || s.status === "awaiting_approval");
  await prisma.task.update({
    where: { id: taskId },
    data: { status: allCompleted ? "completed" : "failed", progress: 100, result: finalReport, logs: logs as any, completedAt: new Date() },
  });
}

// Resume after approval
export async function resumeTaskAfterApproval(taskId: string, approvalId: string, approved: boolean) {
  const approval = await prisma.approval.findUnique({ where: { id: approvalId } });
  if (!approval) throw new Error("Approval not found");
  if (!approved) {
    // Mark tool as denied, continue to next step
    const task = await prisma.task.findUnique({ where: { id: taskId } });
    const plan = task?.plan as unknown as TaskPlan;
    const step = plan?.steps.find(s => s.status === "awaiting_approval");
    if (step) step.status = "failed";
    await prisma.task.update({ where: { id: taskId }, data: { plan: plan as any, status: "running" } });
    return executeTask(taskId);
  }
  // Approved: execute the tool now
  const tool = getTool(approval.toolName);
  const task = await prisma.task.findUnique({ where: { id: taskId } });
  if (!tool || !task) throw new Error("Cannot resume");

  // Execute
  const details = approval.details as any;
  const input = details?.input || {};
  try {
    const output = await tool.execute(input, { userId: task.userId, taskId });
    await prisma.toolCall.create({ data: { taskId, toolName: tool.name, input, output, status: "success" } });
    const plan = task.plan as unknown as TaskPlan;
    const step = plan.steps.find(s => s.status === "awaiting_approval");
    if (step) step.status = "completed";
    await prisma.task.update({ where: { id: taskId }, data: { plan: plan as any, status: "running" } });
  } catch (e: any) {
    await prisma.toolCall.create({ data: { taskId, toolName: tool.name, input, output: { error: e.message }, status: "failed" } });
  }
  return executeTask(taskId);
}
