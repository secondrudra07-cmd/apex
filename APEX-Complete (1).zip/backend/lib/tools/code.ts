import { ToolDefinition } from "./registry";
import { chatCompletion } from "../llm";

export const codeTools: Record<string, ToolDefinition> = {
  code_generate: {
    name: "code_generate",
    description: "Generate code, explain code, debug errors. Provide language and task.",
    parameters: { type: "object", properties: { language: { type: "string" }, task: { type: "string" }, code: { type: "string" } }, required: ["task"] },
    requiresApproval: false, category: "safe",
    execute: async (input) => {
      // Use LLM to generate code
      const prompt = `Generate ${input.language || "code"} for task: ${input.task}. ${input.code ? "Existing code: " + input.code : ""} Return only code with brief explanation.`;
      const result = await chatCompletion({ messages: [{ role: "user", content: prompt }] });
      return { success: true, language: input.language, task: input.task, result };
    },
  },
  code_run_sandbox: {
    name: "code_run_sandbox",
    description: "Run code in restricted sandbox (only simple JS, no network, no fs). Never runs arbitrary commands on phone.",
    parameters: { type: "object", properties: { language: { type: "string" }, code: { type: "string" } }, required: ["code"] },
    requiresApproval: false, category: "safe",
    execute: async (input) => {
      if (input.language && input.language !== "javascript" && input.language !== "js") {
        return { success: false, error: "Only JavaScript sandbox is available in v1. Other languages require approval for external runner." };
      }
      try {
        // Restricted VM - no require, no process, timeout 2s
        const vm = require("vm");
        const sandbox: any = { console: { log: () => {} }, result: null };
        const script = new vm.Script(`result = (function(){ ${input.code} })();`);
        const context = vm.createContext(sandbox);
        script.runInContext(context, { timeout: 2000 });
        return { success: true, output: String(sandbox.result).slice(0, 2000) };
      } catch (e: any) {
        return { success: false, error: e.message };
      }
    },
  },
};
