import { prisma } from "../db";
import { ToolDefinition } from "./registry";
import fs from "fs";
import path from "path";

export const fileTools: Record<string, ToolDefinition> = {
  file_list: {
    name: "file_list",
    description: "List user uploaded files",
    parameters: { type: "object", properties: {}, required: [] },
    requiresApproval: false, category: "safe",
    execute: async (_, ctx) => {
      const files = await prisma.file.findMany({ where: { userId: ctx.userId }, orderBy: { createdAt: "desc" }, take: 50 });
      return { success: true, files };
    },
  },
  file_analyze: {
    name: "file_analyze",
    description: "Analyze a file by ID: extract text, summarize",
    parameters: { type: "object", properties: { fileId: { type: "string" } }, required: ["fileId"] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const file = await prisma.file.findFirst({ where: { id: input.fileId, userId: ctx.userId } });
      if (!file) throw new Error("File not found");
      // If analysis already stored, return
      if (file.analysis) return { success: true, fileName: file.fileName, analysis: file.analysis };
      // Try to read stored file
      let text = "";
      if (file.storagePath && fs.existsSync(file.storagePath)) {
        const buf = fs.readFileSync(file.storagePath);
        if (file.mimeType?.includes("pdf")) {
          try {
            const pdfParse = require("pdf-parse");
            const data = await pdfParse(buf);
            text = data.text.slice(0, 12000);
          } catch { text = buf.toString("utf8").slice(0, 12000); }
        } else {
          text = buf.toString("utf8").slice(0, 12000);
        }
      }
      const preview = text.slice(0, 800) || "(empty or binary file)";
      return { success: true, fileName: file.fileName, preview, length: text.length, note: "Full analysis via LLM summarize step in orchestrator" };
    },
  },
  file_organize: {
    name: "file_organize",
    description: "Organize files: create folders/tags plan (requires approval for actual moves)",
    parameters: { type: "object", properties: { plan: { type: "string", description: "Organization plan description" } }, required: ["plan"] },
    requiresApproval: true, category: "consequential",
    execute: async (input) => {
      return { success: true, message: `Organization plan approved: ${input.plan}`, note: "No files were moved without explicit approval" };
    },
  },
};
