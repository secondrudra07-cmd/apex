import { prisma } from "../db";
import { ToolDefinition } from "./registry";

export const memoryTools: Record<string, ToolDefinition> = {
  memory_write: {
    name: "memory_write",
    description: "Store user-approved memory (preferences, facts, reminders)",
    parameters: { type: "object", properties: { key: { type: "string" }, value: { type: "string" }, category: { type: "string" } }, required: ["key", "value"] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const mem = await prisma.memory.upsert({
        where: { userId_key: { userId: ctx.userId, key: input.key } },
        update: { value: input.value, category: input.category },
        create: { userId: ctx.userId, key: input.key, value: input.value, category: input.category || "fact" },
      });
      return { success: true, memory: mem };
    },
  },
  memory_read: {
    name: "memory_read",
    description: "Read user memories",
    parameters: { type: "object", properties: { query: { type: "string" } }, required: [] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const memories = await prisma.memory.findMany({ where: { userId: ctx.userId, ...(input.query ? { key: { contains: input.query, mode: "insensitive" } } : {}) }, take: 20 });
      return { success: true, memories };
    },
  },
  memory_reminder: {
    name: "memory_reminder",
    description: "Create a reminder (stored as memory, notification scheduling via WorkManager on Android)",
    parameters: { type: "object", properties: { message: { type: "string" }, when: { type: "string", description: "ISO datetime" } }, required: ["message", "when"] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const key = `reminder_${Date.now()}`;
      await prisma.memory.create({ data: { userId: ctx.userId, key, value: `${input.message} @ ${input.when}`, category: "reminder" } });
      return { success: true, message: `Reminder set for ${input.when}: ${input.message}`, note: "Android will show notification at that time via WorkManager" };
    },
  },
};
