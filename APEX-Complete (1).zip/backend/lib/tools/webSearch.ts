import { ToolDefinition } from "./registry";

async function serperSearch(query: string, num = 8) {
  const apiKey = process.env.SEARCH_API_KEY;
  if (!apiKey) {
    // Fallback mock for testing without key
    return [{ title: `Mock result for "${query}"`, url: "https://example.com", snippet: "Mock search result — configure SEARCH_API_KEY for real results.", date: new Date().toISOString().split("T")[0] }];
  }
  const provider = process.env.SEARCH_PROVIDER || "serper";
  if (provider === "serper") {
    const res = await fetch("https://google.serper.dev/search", {
      method: "POST", headers: { "X-API-KEY": apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({ q: query, num }),
    });
    const data = await res.json();
    return (data.organic || []).map((r: any) => ({ title: r.title, url: r.link, snippet: r.snippet, date: r.date || "" }));
  }
  if (provider === "tavily") {
    const res = await fetch("https://api.tavily.com/search", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ api_key: apiKey, query, max_results: num, include_answer: true }),
    });
    const data = await res.json();
    return (data.results || []).map((r: any) => ({ title: r.title, url: r.url, snippet: r.content, date: r.published_date || "" }));
  }
  // Brave
  const res = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${num}`, {
    headers: { "Accept": "application/json", "X-Subscription-Token": apiKey },
  });
  const data = await res.json();
  return (data.web?.results || []).map((r: any) => ({ title: r.title, url: r.url, snippet: r.description, date: "" }));
}

export const webSearchTools: Record<string, ToolDefinition> = {
  web_search: {
    name: "web_search",
    description: "Search the web using real search API. Returns titles, URLs, snippets and dates. Use for research tasks.",
    parameters: { type: "object", properties: { query: { type: "string" }, num_results: { type: "number" } }, required: ["query"] },
    requiresApproval: false, category: "safe",
    execute: async (input) => {
      const results = await serperSearch(input.query, input.num_results || 8);
      return { success: true, query: input.query, results, count: results.length };
    },
  },
  web_fetch: {
    name: "web_fetch",
    description: "Fetch content of a URL (safe, sanitized)",
    parameters: { type: "object", properties: { url: { type: "string" } }, required: ["url"] },
    requiresApproval: false, category: "safe",
    execute: async (input) => {
      // Basic SSRF protection
      const url = new URL(input.url);
      if (url.hostname === "localhost" || url.hostname === "127.0.0.1" || url.hostname.endsWith(".internal")) throw new Error("Blocked URL");
      const res = await fetch(input.url, { headers: { "User-Agent": "APEX-Bot/1.0" } });
      const text = await res.text();
      // Strip scripts, limit
      const sanitized = text.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").slice(0, 15000);
      return { success: true, url: input.url, status: res.status, content: sanitized };
    },
  },
};
