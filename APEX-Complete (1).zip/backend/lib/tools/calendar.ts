import { prisma } from "../db";
import { decrypt } from "../encryption";
import { google } from "googleapis";
import { ToolDefinition } from "./registry";

async function getCalendarClient(userId: string) {
  const token = await prisma.oAuthToken.findFirst({ where: { userId, provider: "calendar" } });
  if (!token) throw new Error("Calendar not connected. Please connect Google Calendar via OAuth.");
  const accessToken = decrypt(token.accessToken);
  const refreshToken = token.refreshToken ? decrypt(token.refreshToken) : undefined;
  const auth = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_CALENDAR_REDIRECT_URI || process.env.GOOGLE_REDIRECT_URI);
  auth.setCredentials({ access_token: accessToken, refresh_token: refreshToken });
  return google.calendar({ version: "v3", auth });
}

export const calendarTools: Record<string, ToolDefinition> = {
  calendar_list: {
    name: "calendar_list",
    description: "List upcoming calendar events. Find deadlines and schedules.",
    parameters: { type: "object", properties: { maxResults: { type: "number" }, timeMin: { type: "string" }, timeMax: { type: "string" } }, required: [] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const calendar = await getCalendarClient(ctx.userId);
      const res = await calendar.events.list({
        calendarId: "primary",
        maxResults: input.maxResults || 20,
        timeMin: input.timeMin || new Date().toISOString(),
        timeMax: input.timeMax,
        singleEvents: true,
        orderBy: "startTime",
      });
      const events = (res.data.items || []).map(e => ({ id: e.id, summary: e.summary, start: e.start, end: e.end, location: e.location, description: e.description?.slice(0, 500) }));
      return { success: true, events };
    },
  },
  calendar_create: {
    name: "calendar_create",
    description: "Create a calendar event (requires approval)",
    parameters: { type: "object", properties: { summary: { type: "string" }, start: { type: "string", description: "ISO datetime" }, end: { type: "string" }, description: { type: "string" } }, required: ["summary", "start", "end"] },
    requiresApproval: true, category: "consequential",
    execute: async (input, ctx) => {
      const calendar = await getCalendarClient(ctx.userId);
      const ev = await calendar.events.insert({
        calendarId: "primary",
        requestBody: { summary: input.summary, start: {dateTime: input.start}, end: {dateTime: input.end}, description: input.description },
      });
      return { success: true, eventId: ev.data.id, htmlLink: ev.data.htmlLink };
    },
  },
};
