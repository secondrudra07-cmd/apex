export interface ToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, any>;
  requiresApproval: boolean;
  category: "safe" | "consequential";
  execute: (input: any, ctx: { userId: string; taskId?: string }) => Promise<any>;
}

// Registry - filled by individual tool modules
import { gmailTools } from "./gmail";
import { calendarTools } from "./calendar";
import { webSearchTools } from "./webSearch";
import { fileTools } from "./files";
import { codeTools } from "./code";
import { memoryTools } from "./memory";

export const toolRegistry: Record<string, ToolDefinition> = {
  ...gmailTools,
  ...calendarTools,
  ...webSearchTools,
  ...fileTools,
  ...codeTools,
  ...memoryTools,
};

export function getTool(name: string): ToolDefinition | undefined {
  return toolRegistry[name];
}

export function listTools() {
  return Object.values(toolRegistry).map(t => ({
    name: t.name,
    description: t.description,
    parameters: t.parameters,
    requiresApproval: t.requiresApproval,
    category: t.category,
  }));
}

export function getToolsForLLM() {
  return Object.values(toolRegistry).map(t => ({
    type: "function" as const,
    function: {
      name: t.name,
      description: t.description,
      parameters: t.parameters,
    },
  }));
}
