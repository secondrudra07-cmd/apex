import { prisma } from "../db";
import { decrypt } from "../encryption";
import { google } from "googleapis";
import { ToolDefinition } from "./registry";

async function getGmailClient(userId: string) {
  const token = await prisma.oAuthToken.findUnique({ where: { userId_provider: { userId, provider: "gmail" } } });
  if (!token) throw new Error("Gmail not connected. Please connect via OAuth.");
  const accessToken = decrypt(token.accessToken);
  const refreshToken = token.refreshToken ? decrypt(token.refreshToken) : undefined;
  const auth = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_REDIRECT_URI);
  auth.setCredentials({ access_token: accessToken, refresh_token: refreshToken });
  // Auto-refresh
  auth.on("tokens", async (tokens) => {
    if (tokens.access_token) {
      const { encrypt } = await import("../encryption");
      await prisma.oAuthToken.update({
        where: { userId_provider: { userId, provider: "gmail" } },
        data: { accessToken: encrypt(tokens.access_token), expiryDate: tokens.expiry_date ? new Date(tokens.expiry_date) : undefined },
      });
    }
  });
  return google.gmail({ version: "v1", auth });
}

export const gmailTools: Record<string, ToolDefinition> = {
  gmail_list: {
    name: "gmail_list",
    description: "List recent emails from Gmail. Use to find important/urgent emails.",
    parameters: { type: "object", properties: { query: { type: "string", description: "Gmail search query, e.g. 'is:unread newer_than:7d'" }, maxResults: { type: "number" } }, required: [] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const gmail = await getGmailClient(ctx.userId);
      const res = await gmail.users.messages.list({ userId: "me", q: input.query || "", maxResults: input.maxResults || 20 });
      const messages = res.data.messages || [];
      const details = await Promise.all(messages.slice(0, 10).map(async m => {
        const msg = await gmail.users.messages.get({ userId: "me", id: m.id!, format: "metadata", metadataHeaders: ["Subject", "From", "Date"] });
        const headers = msg.data.payload?.headers || [];
        const getH = (n: string) => headers.find(h => h.name?.toLowerCase() === n.toLowerCase())?.value || "";
        return { id: m.id, subject: getH("Subject"), from: getH("From"), date: getH("Date"), snippet: msg.data.snippet };
      }));
      return { success: true, messages: details, total: messages.length };
    },
  },
  gmail_read: {
    name: "gmail_read",
    description: "Read full content of a Gmail message by ID",
    parameters: { type: "object", properties: { messageId: { type: "string" } }, required: ["messageId"] },
    requiresApproval: false, category: "safe",
    execute: async (input, ctx) => {
      const gmail = await getGmailClient(ctx.userId);
      const msg = await gmail.users.messages.get({ userId: "me", id: input.messageId, format: "full" });
      const body = msg.data.payload?.body?.data || msg.data.payload?.parts?.[0]?.body?.data;
      const decoded = body ? Buffer.from(body, "base64").toString("utf8") : msg.data.snippet || "";
      return { success: true, id: msg.data.id, snippet: msg.data.snippet, body: decoded.slice(0, 8000) };
    },
  },
  gmail_draft: {
    name: "gmail_draft",
    description: "Create a draft email reply. Requires approval before sending.",
    parameters: { type: "object", properties: { to: { type: "string" }, subject: { type: "string" }, body: { type: "string" } }, required: ["to", "subject", "body"] },
    requiresApproval: true, category: "consequential",
    execute: async (input, ctx) => {
      // This is flagged as requiresApproval — orchestrator will create Approval record and pause
      // If we reach here, approval was granted
      const gmail = await getGmailClient(ctx.userId);
      const raw = Buffer.from(`To: ${input.to}\r\nSubject: ${input.subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${input.body}`).toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
      const draft = await gmail.users.drafts.create({ userId: "me", requestBody: { message: { raw } } });
      return { success: true, draftId: draft.data.id, message: "Draft created (not yet sent — requires send approval)" };
    },
  },
  gmail_send: {
    name: "gmail_send",
    description: "Send an email (requires explicit approval)",
    parameters: { type: "object", properties: { to: { type: "string" }, subject: { type: "string" }, body: { type: "string" } }, required: ["to", "subject", "body"] },
    requiresApproval: true, category: "consequential",
    execute: async (input, ctx) => {
      const gmail = await getGmailClient(ctx.userId);
      const raw = Buffer.from(`To: ${input.to}\r\nSubject: ${input.subject}\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n${input.body}`).toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
      const sent = await gmail.users.messages.send({ userId: "me", requestBody: { raw } });
      return { success: true, messageId: sent.data.id, threadId: sent.data.threadId };
    },
  },
};
