import { NextResponse } from "next/server";
import { google } from "googleapis";
export async function GET() {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const redirectUri = process.env.GOOGLE_CALENDAR_REDIRECT_URI || process.env.GOOGLE_REDIRECT_URI;
  if (!clientId || !redirectUri) return NextResponse.json({ error: "OAuth not configured" }, { status: 500 });
  const auth = new google.auth.OAuth2(clientId, process.env.GOOGLE_CLIENT_SECRET, redirectUri);
  const url = auth.generateAuthUrl({ access_type: "offline", prompt: "consent", scope: ["https://www.googleapis.com/auth/calendar.readonly", "https://www.googleapis.com/auth/calendar.events"] });
  return NextResponse.redirect(url);
}
