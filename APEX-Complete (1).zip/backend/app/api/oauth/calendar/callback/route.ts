import { NextRequest, NextResponse } from "next/server";
import { google } from "googleapis";
import { prisma } from "@/lib/db";
import { encrypt } from "@/lib/encryption";
export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  if (!code) return NextResponse.json({ error: "Missing code" }, { status: 400 });
  const oauth2 = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_CALENDAR_REDIRECT_URI || process.env.GOOGLE_REDIRECT_URI);
  const { tokens } = await oauth2.getToken(code);
  // Reuse gmail status logic but provider=calendar; need userId from state
  const state = req.nextUrl.searchParams.get("state");
  let userId: string | null = null;
  if (state) try { const jwt = await import("jsonwebtoken"); const p: any = jwt.verify(state, process.env.JWT_SECRET!); userId = p.userId; } catch {}
  if (!userId) return NextResponse.json({ error: "Missing user state - initiate OAuth from app while logged in" }, { status: 400 });
  await prisma.oAuthToken.upsert({
    where: { userId_provider: { userId, provider: "calendar" } },
    update: { accessToken: encrypt(tokens.access_token!), refreshToken: tokens.refresh_token ? encrypt(tokens.refresh_token) : undefined, expiryDate: tokens.expiry_date ? new Date(tokens.expiry_date) : undefined, scope: tokens.scope },
    create: { userId, provider: "calendar", accessToken: encrypt(tokens.access_token!), refreshToken: tokens.refresh_token ? encrypt(tokens.refresh_token) : null, expiryDate: tokens.expiry_date ? new Date(tokens.expiry_date) : null, scope: tokens.scope },
  });
  const frontend = process.env.FRONTEND_URL || "/";
  return NextResponse.redirect(`${frontend}/oauth-success?provider=calendar`);
}
