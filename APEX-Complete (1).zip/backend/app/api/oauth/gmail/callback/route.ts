import { NextRequest, NextResponse } from "next/server";
import { google } from "googleapis";
import { prisma } from "@/lib/db";
import { encrypt } from "@/lib/encryption";
import jwt from "jsonwebtoken";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const error = req.nextUrl.searchParams.get("error");
  if (error) return NextResponse.json({ error }, { status: 400 });
  if (!code) return NextResponse.json({ error: "Missing code" }, { status: 400 });

  const oauth2 = new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_REDIRECT_URI);
  const { tokens } = await oauth2.getToken(code);
  oauth2.setCredentials(tokens);
  const oauth = google.oauth2({ version: "v2", auth: oauth2 });
  const me = await oauth.userinfo.get().catch(() => null);

  // Need user association: state contains JWT from app, but for demo we use email lookup
  // In production, app passes ?state=jwt and we decode it
  const state = req.nextUrl.searchParams.get("state");
  let userId: string | null = null;
  if (state) {
    try { const payload = jwt.verify(state, process.env.JWT_SECRET!) as any; userId = payload.userId; } catch {}
  }
  // Fallback: create/find user by email
  let user = null;
  const email = (me?.data.email || tokens.id_token ? JSON.parse(Buffer.from(tokens.id_token!.split(".")[1], "base64").toString()).email : null) as string | null;
  if (email) user = await prisma.user.findUnique({ where: { email } });
  if (userId) user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user && email) user = await prisma.user.create({ data: { email, password: await (await import("bcryptjs")).hash(Math.random().toString(36), 10) } });

  if (!user) return NextResponse.json({ error: "Cannot associate OAuth - please login first and retry" }, { status: 400 });

  await prisma.oAuthToken.upsert({
    where: { userId_provider: { userId: user.id, provider: "gmail" } },
    update: {
      accessToken: encrypt(tokens.access_token!),
      refreshToken: tokens.refresh_token ? encrypt(tokens.refresh_token) : undefined,
      expiryDate: tokens.expiry_date ? new Date(tokens.expiry_date) : undefined,
      scope: tokens.scope,
      email: email || undefined,
    },
    create: {
      userId: user.id, provider: "gmail",
      accessToken: encrypt(tokens.access_token!), refreshToken: tokens.refresh_token ? encrypt(tokens.refresh_token) : null,
      expiryDate: tokens.expiry_date ? new Date(tokens.expiry_date) : null,
      scope: tokens.scope, email: email || null,
    },
  });

  const frontend = process.env.FRONTEND_URL || process.env.NEXT_PUBLIC_APP_URL || "/";
  return NextResponse.redirect(`${frontend}/oauth-success?provider=gmail`);
}
