import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";
export async function GET(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const token = await prisma.oAuthToken.findUnique({ where: { userId_provider: { userId, provider: "gmail" } } });
    if (!token) return NextResponse.json({ connected: false });
    return NextResponse.json({ connected: true, email: token.email, scope: token.scope, expiryDate: token.expiryDate });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
