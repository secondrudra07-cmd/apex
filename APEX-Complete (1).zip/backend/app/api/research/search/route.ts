import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { getTool } from "@/lib/tools/registry";
export async function POST(req: NextRequest) {
  try { await requireAuth(req); } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
  const { query } = await req.json();
  if (!query) return NextResponse.json({ error: "query required" }, { status: 400 });
  const tool = getTool("web_search")!;
  const result = await tool.execute({ query, num_results: 8 }, { userId: "system" } as any);
  return NextResponse.json(result);
}
