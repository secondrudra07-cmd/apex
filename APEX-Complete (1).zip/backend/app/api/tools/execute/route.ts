import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { getTool } from "@/lib/tools/registry";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const { toolName, input, taskId } = await req.json();
    const tool = getTool(toolName);
    if (!tool) return NextResponse.json({ error: "Unknown tool" }, { status: 404 });
    if (tool.requiresApproval) {
      // Create approval if not exists
      const existing = await prisma.task.findFirst({ where: { id: taskId, userId } });
      // Create approval record for UI
      const approval = await prisma.approval.create({
        data: { userId, taskId: taskId || "adhoc", toolName, action: `Execute ${toolName}`, consequences: tool.description, details: input, status: "pending" },
      });
      return NextResponse.json({ requiresApproval: true, approval, message: "Approval required before executing consequential action" }, { status: 202 });
    }
    const result = await tool.execute(input, { userId, taskId });
    if (taskId) await prisma.toolCall.create({ data: { taskId, toolName, input, output: result, status: "success" } });
    return NextResponse.json({ success: true, result });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
