import { NextRequest } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { streamChatCompletion } from "@/lib/llm";
import { understandAndPlan, executeTask } from "@/lib/agent/orchestrator";

/* POST /api/chat — creates conversation message + agent task, returns SSE stream */
export async function POST(req: NextRequest) {
  let userId: string;
  try { ({ userId } = await requireAuth(req)); } catch { return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 }); }

  const { message, conversationId, mode } = await req.json(); // mode: chat | task
  if (!message) return new Response(JSON.stringify({ error: "message required" }), { status: 400 });

  // Ensure conversation
  let convId = conversationId;
  if (!convId) {
    const conv = await prisma.conversation.create({ data: { userId, title: message.slice(0, 50) } });
    convId = conv.id;
  }

  await prisma.message.create({ data: { conversationId: convId, role: "user", content: message } });

  // If mode === task, create agent task via orchestrator (multi-step)
  if (mode === "task" || message.toLowerCase().startsWith("apex") || message.toLowerCase().includes("find") || message.toLowerCase().includes("research") || message.toLowerCase().includes("check my")) {
    const plan = await understandAndPlan(message);
    const task = await prisma.task.create({
      data: { userId, conversationId: convId, command: message, plan: plan as any, status: "pending", progress: 0, logs: [] },
    });
    // Fire-and-forget execution
    executeTask(task.id).catch(console.error);

    return new Response(JSON.stringify({ conversationId: convId, taskId: task.id, plan, status: "pending" }), { headers: { "Content-Type": "application/json" } });
  }

  // Normal streaming chat
  const history = await prisma.message.findMany({ where: { conversationId: convId }, orderBy: { createdAt: "asc" }, take: 20 });
  const llmMessages = [
    { role: "system" as const, content: (await import("@/lib/llm")).SYSTEM_PROMPT },
    ...history.map(m => ({ role: m.role as any, content: m.content })),
  ];

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let full = "";
      try {
        for await (const chunk of streamChatCompletion({ messages: llmMessages })) {
          if (chunk.content) {
            full += chunk.content;
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ content: chunk.content, done: false })}\n\n`));
          }
          if (chunk.done) break;
        }
        await prisma.message.create({ data: { conversationId: convId, role: "assistant", content: full } });
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ done: true })}\n\n`));
        controller.close();
      } catch (e: any) {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: e.message })}\n\n`));
        controller.close();
      }
    },
  });

  return new Response(stream, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" } });
}
