import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const memories = await prisma.memory.findMany({ where: { userId }, orderBy: { updatedAt: "desc" } });
    return NextResponse.json({ memories });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
export async function POST(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const { key, value, category } = await req.json();
    if (!key || !value) return NextResponse.json({ error: "key and value required" }, { status: 400 });
    const mem = await prisma.memory.upsert({ where: { userId_key: { userId, key } }, update: { value, category }, create: { userId, key, value, category: category || "fact" } });
    return NextResponse.json({ memory: mem });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
export async function DELETE(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const { searchParams } = new URL(req.url);
    const key = searchParams.get("key");
    if (!key) return NextResponse.json({ error: "key required" }, { status: 400 });
    await prisma.memory.delete({ where: { userId_key: { userId, key } } });
    return NextResponse.json({ success: true });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
