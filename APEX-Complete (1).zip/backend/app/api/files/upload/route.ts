import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import fs from "fs";
import path from "path";

export async function POST(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const form = await req.formData();
    const file = form.get("file") as File | null;
    if (!file) return NextResponse.json({ error: "file required" }, { status: 400 });
    const maxMb = parseInt(process.env.MAX_UPLOAD_MB || "10");
    if (file.size > maxMb * 1024 * 1024) return NextResponse.json({ error: `File too large (max ${maxMb}MB)` }, { status: 413 });
    const buf = Buffer.from(await file.arrayBuffer());
    const storageDir = "/tmp/apex-uploads";
    fs.mkdirSync(storageDir, { recursive: true });
    const storagePath = path.join(storageDir, `${Date.now()}_${file.name}`);
    fs.writeFileSync(storagePath, buf);
    const record = await prisma.file.create({ data: { userId, fileName: file.name, mimeType: file.type, size: file.size, storagePath } });
    return NextResponse.json({ file: record }, { status: 201 });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
