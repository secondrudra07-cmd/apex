import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";
export async function GET(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const files = await prisma.file.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50 });
    return NextResponse.json({ files });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
