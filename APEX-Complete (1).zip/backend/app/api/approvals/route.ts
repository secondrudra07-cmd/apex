import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const approvals = await prisma.approval.findMany({ where: { userId, status: "pending" }, orderBy: { createdAt: "desc" }, include: { task: true } });
    return NextResponse.json({ approvals });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
