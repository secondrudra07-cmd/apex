import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { resumeTaskAfterApproval } from "@/lib/agent/orchestrator";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId } = await requireAuth(req);
    const { approved } = await req.json();
    const approval = await prisma.approval.findFirst({ where: { id: params.id, userId } });
    if (!approval) return NextResponse.json({ error: "Not found" }, { status: 404 });
    await prisma.approval.update({ where: { id: params.id }, data: { status: approved ? "approved" : "denied", decidedAt: new Date() } });
    // Resume task if approved
    if (approval.taskId !== "adhoc") {
      resumeTaskAfterApproval(approval.taskId, approval.id, !!approved).catch(console.error);
    }
    return NextResponse.json({ approval: { ...approval, status: approved ? "approved" : "denied" } });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
