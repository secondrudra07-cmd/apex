import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { understandAndPlan, executeTask } from "@/lib/agent/orchestrator";

export async function GET(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const tasks = await prisma.task.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50, include: { approvals: true, toolCalls: true } });
    return NextResponse.json({ tasks });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}

export async function POST(req: NextRequest) {
  try {
    const { userId } = await requireAuth(req);
    const { command, conversationId } = await req.json();
    if (!command) return NextResponse.json({ error: "command required" }, { status: 400 });
    const plan = await understandAndPlan(command);
    const task = await prisma.task.create({ data: { userId, conversationId: conversationId || null, command, plan: plan as any, status: "pending", progress: 0, logs: [] } });
    executeTask(task.id).catch(console.error);
    return NextResponse.json({ task }, { status: 201 });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 400 }); }
}
