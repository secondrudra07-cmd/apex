import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId } = await requireAuth(req);
    const task = await prisma.task.findFirst({ where: { id: params.id, userId } });
    if (!task) return NextResponse.json({ error: "Not found" }, { status: 404 });
    if (task.status === "completed" || task.status === "cancelled") return NextResponse.json({ message: "Already finished", task });
    const updated = await prisma.task.update({ where: { id: params.id }, data: { status: "cancelled", logs: [...(task.logs as any[] || []), { event: "cancelled by user", at: new Date().toISOString() }] as any } });
    return NextResponse.json({ task: updated });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
