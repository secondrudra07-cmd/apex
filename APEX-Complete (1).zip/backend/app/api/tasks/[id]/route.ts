import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { userId } = await requireAuth(req);
    const task = await prisma.task.findFirst({ where: { id: params.id, userId }, include: { toolCalls: true, approvals: true } });
    if (!task) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ task });
  } catch { return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); }
}
