import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET() {
  let dbStatus: "connected" | "disconnected" = "disconnected";
  try {
    await prisma.$queryRaw`SELECT 1`;
    dbStatus = "connected";
  } catch {}
  const llmConfigured = !!process.env.LLM_API_KEY;
  const oauthConfigured = !!process.env.GOOGLE_CLIENT_ID;

  return NextResponse.json({
    status: "ok",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
    db: dbStatus,
    checks: {
      database: dbStatus,
      llm: llmConfigured ? "configured" : "missing LLM_API_KEY",
      oauth: oauthConfigured ? "configured" : "missing GOOGLE_CLIENT_ID",
      ghidra: "available via REA integration (optional)",
    },
  });
}
