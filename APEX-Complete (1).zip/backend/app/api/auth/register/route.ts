import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { hashPassword, signAccessToken, signRefreshToken, createSession } from "@/lib/auth";
import { z } from "zod";

const schema = z.object({ email: z.string().email(), password: z.string().min(8), name: z.string().optional() });

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, name } = schema.parse(body);
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return NextResponse.json({ error: "Email already registered" }, { status: 409 });
    const hashed = await hashPassword(password);
    const user = await prisma.user.create({ data: { email, password: hashed, name } });
    const token = signAccessToken({ userId: user.id, email: user.email });
    const refreshToken = signRefreshToken({ userId: user.id });
    await createSession(user.id, refreshToken);
    return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name }, token, refreshToken }, { status: 201 });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Invalid request" }, { status: 400 });
  }
}
