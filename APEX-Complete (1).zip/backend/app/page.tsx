export default function Home() {
  return (
    <main style={{ fontFamily: "system-ui", padding: 40, background: "#020617", color: "#e2e8f0", minHeight: "100vh" }}>
      <h1 style={{ fontSize: 36, fontWeight: 800 }}>APEX Backend</h1>
      <p>Autonomous Personal AI Agent — API is live.</p>
      <ul>
        <li><a href="/api/health" style={{ color: "#22d3ee" }}>/api/health</a> — Health check</li>
        <li><code>POST /api/auth/register</code> — Register</li>
        <li><code>POST /api/auth/login</code> — Login</li>
        <li><code>POST /api/chat</code> — Chat + Agent tasks</li>
        <li><code>GET /api/tasks</code> — Task history</li>
        <li><code>GET /api/oauth/gmail</code> — Connect Gmail</li>
      </ul>
      <p style={{ marginTop: 24, color: "#94a3b8" }}>Backend URL for Android: Set in App → Settings → Backend URL</p>
    </main>
  );
}
