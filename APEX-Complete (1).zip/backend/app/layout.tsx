export const metadata = { title: "APEX Backend", description: "APEX Personal AI Agent" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body style={{ margin: 0 }}>{children}</body></html>;
}
