# APEX Backend
Next.js + Prisma + PostgreSQL. Deploy to Vercel. See root README and DEPLOYMENT.md
