# APEX — Autonomous Personal AI Agent

> **Real native Android app + real cloud backend. Not a prototype.**

APEX is a personal AI agent that understands commands, makes multi-step plans, calls real tools, verifies results, and reports completion. It runs as a **native Kotlin/Compose Android app** connected over HTTPS to a **Next.js + PostgreSQL cloud backend** that hosts the agent orchestration engine.

---

## ⚠️ You only have an Android phone — no computer required

This repository is **fully cloud-buildable**. You never need Android Studio locally. The GitHub Actions workflow builds a real installable debug APK for you.

---

## Architecture

```
Android (Kotlin + Compose)  --HTTPS-->  Next.js Backend  -->  PostgreSQL (Supabase)
   | Room + Keystore + TTS/STT                | Agent Engine + Tool Registry
   | Retrofit + Notifications                 | LLM (OpenAI/Anthropic/Groq)
   └──────────────────────────────────────────┘
```

- **Android:** Kotlin, Jetpack Compose Material3, Retrofit, Room, Android Keystore, WorkManager, Speech-to-Text, Text-to-Speech
- **Backend:** Next.js 14 (TypeScript), REST API, Prisma + PostgreSQL, JWT auth, encrypted OAuth tokens, streaming SSE
- **Agent:** Understand → Plan → Select tools → Validate permissions → Execute → Inspect → Continue → Final report

---

## Quick Start (Phone Only)

### 1. Fork this repository
1. Open `github.com/YOUR_USERNAME/apex` on your phone browser
2. Tap **Fork** → Create fork

### 2. Get your debug APK (no local build)
1. In your fork, tap **Actions** → `Android Build` workflow → **Run workflow** → Run
2. Wait 5-8 minutes — workflow installs JDK 17, Android SDK, builds `assembleDebug`
3. Download artifact `apex-debug-apk` → install APK on your phone (allow unknown sources)

### 3. Deploy backend (required for the app to work)
You need a free cloud backend — see **[DEPLOYMENT.md](./DEPLOYMENT.md)** for step-by-step phone-friendly instructions.

- Vercel for backend (free)
- Supabase for PostgreSQL (free)
- OpenAI or Groq for LLM

After deployment, set the backend URL in the app: **Settings → Backend URL** (or via `local.properties` before build).

### 4. Configure Google OAuth (for Gmail/Calendar)
See **[OAUTH_SETUP.md](./OAUTH_SETUP.md)** — you create a Google Cloud project on your phone and paste the client IDs into Vercel env vars.

Without OAuth, APEX still works for research, file analysis, coding, and personal assistant tasks. Gmail/Calendar will show **Not connected** until OAuth is configured.

---

## Repository Structure

```
apex/
├── android/                 # Native Android app (Kotlin + Compose)
│   ├── app/src/main/java/com/apex/agent/
│   │   ├── ui/screens/     # 13 screens (Splash, Login, Dashboard, Chat...)
│   │   ├── data/           # Retrofit API, Room DB, Keystore
│   │   └── navigation/     # NavHost
│   ├── build.gradle.kts
│   └── gradle/wrapper/     # gradlew (cloud buildable)
├── backend/                # Next.js backend
│   ├── app/api/            # REST endpoints
│   ├── lib/agent/          # Orchestrator + tool registry
│   ├── lib/tools/          # Gmail, Calendar, Research, Files...
│   └── prisma/schema.prisma
├── .github/workflows/android-build.yml
├── .env.example
├── DEPLOYMENT.md
├── OAUTH_SETUP.md
└── TESTING_REPORT.md
```

---

## Backend Environment

Copy `.env.example` to `.env` and fill in **your own keys** (never commit real keys):

```bash
DATABASE_URL="postgresql://..."
JWT_SECRET="your-random-64-char-string"
ENCRYPTION_KEY="32-byte-hex-key"
LLM_PROVIDER="openai" # or anthropic, groq, openrouter
LLM_API_KEY="sk-..."
LLM_MODEL="gpt-4o-mini"
GOOGLE_CLIENT_ID="..."
GOOGLE_CLIENT_SECRET="..."
GOOGLE_REDIRECT_URI="https://your-backend.vercel.app/api/oauth/gmail/callback"
NEXT_PUBLIC_APP_URL="https://your-backend.vercel.app"
```

See `.env.example` for full list.

---

## Security — Never in the APK

- ✅ AI keys, DB passwords, OAuth secrets live **only on backend** (encrypted at rest, never in `BuildConfig`)
- ✅ Android stores only short-lived JWT + refresh token in EncryptedSharedPreferences (Keystore)
- ✅ Backend uses per-user isolation (`userId` on every query)
- ✅ Destructive actions require explicit **Approval Card** (send email, delete, publish, purchase)
- ✅ Untrusted content (emails, web pages) is sanitized and never overrides system instructions

---

## Build APK Locally (Optional, if you later get a computer)

```bash
# Configure backend URL without recompiling:
echo "BACKEND_URL=https://your-backend.vercel.app" > android/local.properties
# or set in app Settings UI

# Build
cd android
./gradlew assembleDebug
# APK at android/app/build/outputs/apk/debug/app-debug.apk
```

**Release signing** (secure, no keystore committed):
1. Generate keystore locally once: `keytool -genkeypair ...`
2. Base64 encode: `base64 my-release.jks | pbcopy`
3. Add GitHub Secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`
4. Workflow will sign `assembleRelease` when secrets exist — see `.github/workflows/android-build.yml`.

---

## Testing

See [TESTING_REPORT.md](./TESTING_REPORT.md) for what was tested and how.

Quick checks:

```bash
# Backend
cd backend && npm install && npm run build && npm run test

# Android (requires Android SDK)
cd android && ./gradlew assembleDebug
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| App shows **Backend unavailable** | Check Settings → Backend URL, ensure Vercel deployment is live (`/api/health` should return 200) |
| Gmail says Not connected | Finish OAuth setup in OAUTH_SETUP.md, then tap “Connect Gmail” and approve |
| APK won't install | Enable “Install unknown apps” for your browser/file manager |
| Workflow fails | Check Actions logs — most common: missing `local.properties` is now optional, fixed in this repo |

---

## License

MIT — see LICENSE

Built for the APEX project. Contributions welcome.
